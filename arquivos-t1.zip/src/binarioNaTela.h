#ifndef T1_BINARIONATELA_H
#define T1_BINARIONATELA_H

void binarioNaTela(char *nomeArquivoBinario);

#endif
