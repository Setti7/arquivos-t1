#ifndef T1_BINARIONATELA_H
#define T1_BINARIONATELA_H

void binarioNaTela(char *nomeArquivoBinario);

void scan_quote_string(char *str);

#endif
